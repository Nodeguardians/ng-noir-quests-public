const { testSpell } = require("./testsuites/testSpell");

describe("DaggerSpell (Part 3)", function () {

  testSpell("Public", "test/inputs");

});